mongo world_data --eval "db.dropDatabase()"
mongoimport --db world_data --collection airports       --type json --file C:\Users\Ben\Desktop\GEO\geo\geojson\airports.geojson    --jsonArray
mongoimport --db world_data --collection countries      --type json --file C:\Users\Ben\Desktop\GEO\geo\geojson\countries.geojson            --jsonArray
mongoimport --db world_data --collection meteorites     --type json --file C:\Users\Ben\Desktop\GEO\geo\geojson\meteorite.geojson   --jsonArray
mongoimport --db world_data --collection volcanos       --type json --file C:\Users\Ben\Desktop\GEO\geo\geojson\volcanos.geojson       --jsonArray
mongoimport --db world_data --collection earthquakes    --type json --file C:\Users\Ben\Desktop\GEO\geo\geojson\earthquakes.geojson          --jsonArray
mongoimport --db world_data --collection cities         --type json --file C:\Users\Ben\Desktop\GEO\geo\geojson\world_cities.geojson         --jsonArray
mongoimport --db world_data --collection states         --type json --file C:\Users\Ben\Desktop\GEO\geo\geojson\state_borders.geojson        --jsonArray
mongoimport --db world_data --collection terrorism      --type json --file C:\Users\Ben\Desktop\GEO\geo\geojson\globalterrorism.geojson        --jsonArray